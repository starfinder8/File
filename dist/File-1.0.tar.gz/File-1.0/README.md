# File
A package for saving and loading files

## How to use
**save('your_data', 'your_file_name')<br>**

**load('your_file_name')<br>**
