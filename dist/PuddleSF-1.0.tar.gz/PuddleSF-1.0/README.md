# PuddleSF
A package for saving and loading files

## How to use
**import dir**

**SF.save('your_data', 'your_file_name')<br>**

**SF.load('your_file_name')<br>**
